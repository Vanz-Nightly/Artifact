package com.mardous.booming.playback.shuffle

enum class OpenShuffleMode {
    On, Off, Remember
}