package com.mardous.booming.core.model.shuffle

enum class GroupShuffleMode {
    ByGroup,
    BySong,
    FullRandom
}