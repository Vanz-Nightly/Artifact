package com.mardous.booming.ui.adapters.album

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.LayoutRes
import androidx.fragment.app.FragmentActivity
import coil.load
import com.mardous.booming.R
import com.mardous.booming.databinding.ItemAlbumBinding
import com.mardous.booming.ui.IAlbumCallback

data class RemoteAlbumUiModel(
    val id: Long,
    val title: String,
    val imageUrl: String?,
    val isAvailableLocally: Boolean = false
)

class RemoteAlbumAdapter(
    private val activity: FragmentActivity,
    items: List<RemoteAlbumUiModel>,
    @LayoutRes private val itemLayoutRes: Int = R.layout.item_album,
    private val callback: IAlbumCallback? = null
) : androidx.recyclerview.widget.RecyclerView.Adapter<RemoteAlbumAdapter.ViewHolder>() {

    var dataSet: List<RemoteAlbumUiModel> = items
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    inner class ViewHolder(val binding: ItemAlbumBinding) : androidx.recyclerview.widget.RecyclerView.ViewHolder(binding.root) {
        init {
            binding.root.setOnClickListener {
                val album = dataSet[adapterPosition]
                if (album.isAvailableLocally) {
                    callback?.albumClick(null /* convert to your Album */, null)
                } else {
                    // Show message here if album not available locally
                    // e.g., Toast.makeText(activity, "Album not available locally", Toast.LENGTH_SHORT).show()
                }
            }
        }

        fun bind(album: RemoteAlbumUiModel) {
            binding.title.text = album.title
            binding.image.load(album.imageUrl) {
                placeholder(R.drawable.ic_album)
                error(R.drawable.ic_album)
                crossfade(true)
            }
            // Grey out non-local albums
            binding.root.alpha = if (album.isAvailableLocally) 1.0f else 0.5f
            binding.root.isClickable = album.isAvailableLocally
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemAlbumBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(dataSet[position])
    }

    override fun getItemCount(): Int = dataSet.size
}
