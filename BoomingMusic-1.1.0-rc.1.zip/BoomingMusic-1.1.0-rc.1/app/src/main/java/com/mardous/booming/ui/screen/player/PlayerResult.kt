package com.mardous.booming.ui.screen.player

import android.net.Uri

data class SaveCoverResult(val isWorking: Boolean, val uri: Uri? = null)